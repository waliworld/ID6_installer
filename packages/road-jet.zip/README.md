# Road Jet

Road Jet displays a small jet over a scrolling five-lane road. Accelerator pedal position sets how far up the screen the jet travels. Steering moves the jet between lanes with a small deadband to keep it steady around the center. The road scrolls faster as pedal input increases.

## Preview

Open `Road-Jet.html` in a browser. Hold Up to build throttle and use Left and Right to steer. The on-screen buttons support pointers and touch.

## iDrive 6 preview build

`Road-Jet-iDrive6-QNX65.zip` contains a standalone `RoadJet` plugin folder. It is separate from the released ID6 Apps packages and desktop installers. On a compatible NBT Evo with authorized SSH already available, the standard plugin root is `/var/opt/hmi/data/ID5/Plugins/`. The menu entry is **Road Jet** under **My Vehicle**. Its only files are under the `RoadJet` folder. Removing that folder and restarting iDrive removes the entry.

The plugin reads diagnostic data only while its screen is open. It first tries the HSFZ gateway, with the same optional `gateway-ip.txt` override as ShiftDeck. If the gateway cannot connect, it tries the shared MOST fallback. The DME-only MOST path displays pedal response and centers the jet because EPS steering is unavailable on that path. Brief dropouts keep the last valid reading. A sustained loss pauses the image in place until telemetry resumes. Pedal and steering are tracked separately. iDrive continues to manage screen access. Engine calibration, steering, and head-unit security settings are outside the plugin's scope.

The candidate uses normalized pedal data from DME8FF_R and a calibrated EPS_G11 steering pinion angle. Initial vehicle validation should confirm both signals, including left/right direction, against independent readings. Other ECU profiles may need their own signal mappings. [DME reference](https://github.com/cauliflowermossgrape/idrive7-apps/blob/HEAD/apps/live_data/useful.js) · [EPS reference](https://github.com/strulock/m550-analyzer)

## Build and verification

Build with `source/native/build.sh` and create `RoadJet_ALL_Images.zip` with `source/native/tools/road_jet_art.py` using Pillow. The package contains the two build outputs plus the plugin manifest, XML and image database.

The preview build was compiled on Cachy using GCC 4.4.2 for ARM QNX 6.5. The plugin loaded and the worker started in the reference QNX virtual machine. A simulated HSFZ gateway verified read-only requests, pedal fallback, signed steering and rejection of invalid sensor data. A fake DSI library verified the automatic switch to MOST and pedal-only mode. Live signal behavior on a physical head unit is pending.

The taller play area includes passing traffic cones and police cars.
