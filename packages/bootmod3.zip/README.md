# iDrive 6 optional controls

These are optional builds for the NBT Evo QNX 6.5 ARM plugin ABI. Bootmod3 Suite is in beta. xDrive Control is experimental. Test each app separately on the intended car. Existing temporary SSH, a known compatible app framework, a functioning diagnostic gateway at 169.254.21.3, and available connector IDs are required. The plugin folders are Bootmod3Suite (111) and XDriveControl (112). Install the chosen folder under /var/opt/hmi/data/ID5/Plugins, give the -qnx worker execute permission, then restart iDrive while parked. Start with a parked test.

## Bootmod3 Suite

Maps 1–4 are available on the main screen. OPTIONS opens Exhaust flap, Active Sound and Burbles. Each request starts with the upstream CustomROM marker lookup at 0x807FFE50. A unique known ROM is required. A different marker address or an unknown ROM disables commands. Maps and the three burble presets (4, 8, 12) use bounded profile-specific memory writes with readback. Exhaust and Active Sound report DME acknowledgement. The tune and hardware determine which requests work. Map switching, Exhaust Flap and Active Sound can fall back to MOST. Burble presets require HSFZ.

[Bootmod3 protocol and profiles](https://github.com/cauliflowermossgrape/idrive7-apps/tree/8d860de/apps/live_adjustments)

## xDrive Control (experimental)

The DSC path is limited to the upstream-tested DSC indices 0F2510 and 0F2850. It requires a positive mode-control read and live transfer case state. The second selection confirms the request. The worker checks Park via EGS DA2E, zero engine RPM, and zero speed immediately before a write. Apply the parking brake at the confirmation screen. Cars that do not supply the expected EGS data cannot switch. The QNX port and DA2E mapping on compatible xDrive cars still need vehicle validation.

RWD is temporary. Cycle the ignition to restore AWD, or use the restore button on DSC 0F2850. The app checks the transfer case before reporting a confirmed change. An unsupported DSC, missing reply or unknown mode prevents the write. This does not flash a transfer case or provide xDelete calibration options.

[DSC mode and restore measurements](https://github.com/cauliflowermossgrape/idrive7-apps/issues/64)
