# Dashboard package

The dashboard includes BoostDeck, ShiftDeck, Engine Fault Codes and MHD+ Suite. Open Options in MHD+ Suite for Exhaust Flap or Max Cooling.

The dashboard workers use HSFZ with MOST fallback. The dedicated Exhaust Flap worker also falls back to MOST. Set the diagnostic gateway per app in gateway-ip.txt. See AgentReadMe.md in the repository for install and migration steps.
