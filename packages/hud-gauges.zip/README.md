# HUD Gauges

See the GitHub repository's AgentReadMe.md for compatibility and deployment. This package targets the tested NBTevo_N18032I reference 340i with the corresponding factory windshield HUD and diagnostic gateway. Install the HudTest folder only, permit the QNX worker to execute, and restart iDrive after verifying the uploaded files.

Open My Vehicle → HUD Gauges and check Show HUD gauges. The live tach spans 0–8,000 RPM and the thicker redline zone starts at 6,700 RPM. Boost is a numeric PSI readout. The checkbox persists across boots and can be unchecked to clear the overlay. Validate the overlay while parked before use.
