# TunedByWali · NBT Evo Toolbox

A lightweight PC program that walks a client through the **whole** NBT Evo (iDrive 5/6)
job as one guided procedure:

**Connect → Enable SSH → Identify → Install gauges → Full-screen CarPlay → Secure**

> **Client guide:** [Quick Start.md](Quick%20Start.md) · **Build/dev:** [docs/INTEGRATION.md](docs/INTEGRATION.md)

---

## What it does

- **Enable SSH** — flashes a patched `starter.cfg` over the diagnostic network so root SSH
  comes up on the head unit; reverts to stock when you're done. *(tools/ssh-unlock)*
- **Identify** — read-only read-out of firmware, display, framework match, installed apps,
  and which CarPlay method the unit needs. *(tools/hu-info + the Go `inspect` check)*
- **Install gauges** — BoostDeck, ShiftDeck and MHD Maps, with backup + automatic rollback.
  *(the existing Go engine — unchanged)*
- **Full-screen CarPlay** — routes by firmware: a coding parameter on newer builds, or an
  SSH aspect-ratio patch on older ones (the case the enabled SSH unlocks).
  *(see [docs/CARPLAY_FULLSCREEN.md](docs/CARPLAY_FULLSCREEN.md))*
- **Secure** — closes SSH back up so a customer's unit isn't left open as root.
- **Add-ons** — installs community head-unit add-ons over SSH (Android Auto / NBT-AAD, the AA
  main-menu tile, iDrive Plus info pages, EntryNav2 AA — kizapp and entry-aad) from each project's
  own release, with on-device backup and clean removal. See [docs/ADDONS.md](docs/ADDONS.md).
- **Coding & FSC** — read/sign/write coding and mint/apply feature codes (including real CarPlay
  activation, FSC `0x0143` + `CARPLAY_SWT`, and full-screen `CARPLAY_FULLSCREEN`) via the vendored
  **MIT nbt-evo-toolkit**. Auto-detects VIN and finds your PSdZData on the system; backs up coding
  before any write; owner-VIN consent gate never bypassed. See [docs/CODING_FSC.md](docs/CODING_FSC.md).

**Platform-aware.** The unit is identified first (NBT Evo vs EntryNav2) and the wizard only offers
what that platform supports — on NBT Evo, enabling SSH *is* OPT_DEBUG (one mechanism); EntryNav2
roots differently and has its own Android Auto (entry-aad). See [docs/PLATFORMS.md](docs/PLATFORMS.md).

## App catalog (synced from upstream)

Upstream now publishes the **compiled app payloads** in [`packages/`](packages) — vendored here, so
no separate payload is needed. All of them install through the guarded add-on installer:

| Package | Apps | Notes |
|---|---|---|
| `dashboard.zip` | BoostDeck, ShiftDeck, MHD+ Suite, Engine Fault Codes | boost + Active Ethanol, map switching, Exhaust Flap, Max Cooling |
| `hud-gauges.zip` | HUD Gauges | windshield tach + boost PSI; targets the reference 340i factory HUD |
| `bootmod3.zip` | Bootmod3 Suite | **beta** — CustomROM map switching, Active Sound, Exhaust Flap |
| `xdrive.zip` | xDrive Control | **experimental** — DSC-dependent, needs HSFZ |
| `road-jet.zip` | Road Jet | requires a 1280 × 480 display |
| `beamer.zip` | BEAMer | requires a 1280 × 480 display |

Firmware eligibility is in [`source/docs/COMPATIBILITY.md`](source/docs/COMPATIBILITY.md)
(installer-eligible: **N18092I**, **P18362I**). Identify checks the unit before anything installs.

> Upstream's own desktop installer is now **v0.7.1 beta** (selectable menus + uninstall) and is
> distributed as a release binary — its Go source is no longer published. This repo keeps its own
> engine for the original gauge flow and installs the newer apps through the add-on framework.

One branded wizard (`source/index.html`) is the whole UI; the stepper gates each stage and
every risky action is confirmed. It's responsive for phone and desktop.

## Self-reliant backend

The app validates itself on launch (**self-check**: Python, OpenSSH, ENET link, bundled
tools, and an offline self-test of the SSH flasher) and runs every stage itself. The Go
server owns the gauge engine; the SSH / self-check / CarPlay stages are a tested Python
backend (`tools/toolbox.py`) the server shells out to via `source/toolbox.go` — one app,
one build. See [docs/INTEGRATION.md](docs/INTEGRATION.md).

| Stage | Status |
|---|---|
| Self-check (launch) | ✅ implemented + tested |
| Connect, Install gauges, Identify (core) | ✅ work today (Go engine) |
| Enable / Close SSH | ✅ implemented (drives the vendored flasher); flash needs a car |
| Full-screen CarPlay / Activate CarPlay | ⛔ implemented but **gated** — applies only a profile verified on a reference car; otherwise reports "pending" and writes nothing |

The wizard degrades gracefully: any stage whose backend isn't present shows a clear
"needs app build" note instead of breaking, so a gauge-only build still ships.

## Two firmware gates (don't assume overlap)

- **SSH unlock** supports the **`007.xxx`** starter.cfg family (not `001_05x`).
- **Gauge install** supports specific HMI builds (`NBTevo_N18092I / V20153I / Y24073J`).

A car can pass one and not the other; Identify surfaces both before anything is flashed.

## Running it

**It's one program now — pure Python, no build step.** See [HOW_TO_RUN.md](HOW_TO_RUN.md).

- **End users:** download the double-click program from the **Releases** page
  (`…-windows-x64.exe` / `…-macos`) — no Python needed — and run it. The toolbox opens
  in the browser.
- **From source:** double-click `Start Toolbox (Windows).bat` / `Start Toolbox (Mac).command`,
  or run `python app.py`. The compiled app payloads are vendored in `packages/`, so there's no
  separate payload to obtain. OpenSSH (built into Windows 10/11 and macOS) is the only system
  requirement.

The release executables are built automatically by CI on real Windows/macOS runners
(`.github/workflows/release.yml` + `packaging/toolbox.spec`) whenever a version tag is pushed,
bundling Python + the UI + backend + `packages/` + the toolkit into one file.

> The older Go server (`source/*.go`) is superseded by `app.py` and kept only for reference;
> the app no longer needs Go or a compile step.

## Safety & authorization

- **Enable/Close SSH is a live-partition flash — brick-capable on the wrong unit.** Keep the
  offline self-test mandatory; `--revert` is first recovery, serial/eMMC the backstop.
- This is a **parked preview** — verify gauges, map switching and CarPlay on the car.
- Install only on vehicles **you own or are authorized to modify**, and record who approved it.

## Non-commercial / credits

**This project is for non-commercial, community use** — not sold, not bundled with anything
sold. Add-ons are installed from their authors' own releases, not redistributed here. Full
credits and licenses (NBT Evo Gauges, Xayanix SSH unlocker, Viaszx HU Info, Sq00ky NBT-AAD,
deathwalker80 nbt-aa-tile & iDrive Plus, Keukenrol123522, kizapp EntryNav2, BimmerWest
remote-start FSC): see [NOTICES.md](NOTICES.md).

Toolbox + integration: **TunedByWali · TBW Performance.** Issues or wins: **b58devkev** on Instagram.
