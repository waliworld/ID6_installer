# Add-ons

The toolbox can install community head-unit add-ons over the root SSH it enables —
reusing one framework (`tools/addons/addon_kit.py`, registry `tools/addons/addons.json`).
It adapts each project's USB install to a direct SSH push (no USB stick), always backing up
on-device first and recording a removal marker. **No third-party binaries ship in this repo**
— you stage each add-on from its own release into a *kit* folder. Credits/licenses: `NOTICES.md`.

## How an install runs

`addon-install {id, kit, Head}` →
1. validate the kit (expected files present),
2. **platform guard** — identify the *connected* unit from the car itself and refuse if it
   doesn't match the add-on's `platform` (an NBT-Evo program can't land on an EntryNav2, or
   vice versa). UI filtering by platform is the first line; this server-side guard is the one
   that actually protects the unit.
3. **prerequisite check** — run the add-on's `verify` (e.g. Android Auto's state file must
   exist before the tile or iDrive Plus installs); refuse if missing.
4. remount the HU filesystem read-write,
5. back up each `backup_paths` entry to `/var/opt/tbw-addons/<id>.<timestamp>/`,
6. upload the kit (whole folder, or listed files),
7. run the add-on's verified `steps`,
8. write an install marker. Any failed step stops and points at the backup.

Each add-on declares `platform` (`nbt_evo` / `entrynav2`), and dependent add-ons declare a
`verify` command + `verify_hint`. Both guards run before anything is written.

`addon-remove` runs the add-on's `remove_steps` (restoring hooked files); `addon-status`
reports installed/not. In the wizard: **Add-ons → Show available add-ons**, then Install /
Remove / Status per card (enabled once SSH is on).

## The add-ons

### Android Auto & info add-ons

| id | What | License | Platform | Needs |
|---|---|---|---|---|
| `nbt-aad` | **Android Auto** (the base) | PolyForm NC | NBT Evo | — |
| `aa-menu-tile` | AA tile in the main menu | PolyForm NC | NBT Evo | `nbt-aad` |
| `idrive-plus-plugins` | Weather/news/fuel/traffic pages | PolyForm NC | NBT Evo | `nbt-aad` |
| `entry-aad` | Android Auto for EntryNav2 | PolyForm NC | EntryNav2 | — |

### ID6Apps packages (vendored in `packages/`)

Upstream publishes the compiled payloads, so these need no external download — unzip the package
from `packages/` and point the card's **Kit folder** at the unzipped folder. All are NBT Evo and
require a matched firmware profile (**N18092I / P18362I**, see `source/docs/COMPATIBILITY.md`);
they install into `/var/opt/hmi/data/ID5/Plugins/` with the target app folders backed up first.

| id | Apps installed | Notes |
|---|---|---|
| `apps-dashboard` | BoostDeck, ShiftDeck, MhdMaps, EngineCodes | the core gauge/diagnostic set |
| `apps-hud-gauges` | HudTest | targets the reference 340i factory HUD |
| `apps-bootmod3` | Bootmod3Suite | beta; burble presets still need HSFZ |
| `apps-xdrive` | XDriveControl | experimental; DSC-dependent, needs HSFZ |
| `apps-road-jet` | RoadJet | needs 1280 × 480 |
| `apps-beamer` | BEAMer | needs 1280 × 480 |

These install the package's **baked layout**, so the display must match (that's why Road Jet and
BEAMer are 1280 × 480 only). Upstream's own v0.7.1 installer generates layouts per display; use it
if you need a size the package doesn't ship.

**Android Auto (NBT-AAD) is the foundation** on NBT Evo — the tile and iDrive Plus both require
it (the installer checks `/opt/aa/nbt-aad` is present first). Install `nbt-aad` first. EntryNav2
uses `entry-aad`, which is self-contained and runs its own `--compat` check before writing.

All four now carry their **published install steps** (transcribed from each project's own install
guide): NBT-AAD places `/opt/aa/nbt-aad` + the `NbtAad` plugin and installs the `pf_aa` firewall
rule; `entry-aad` places `/opt/aa` + the `EntryAad` plugin (note it remounts `/`, not
`/net/hu-omap/fs/sda0` — EntryNav2's layout differs). Kits are streamed to the HU over the SSH
shell, so no `scp` is required on the unit. **Still test each on a reference car before fleet use.**

### Staging a kit
Download the add-on's release (link in each card / `source` in the manifest), unzip it, and point
the card's **Kit folder** at the unzipped folder. `nbt-aad`: the folder holding `nbt-aad`, `pf_aa`
and the extracted `Releases/`. `aa-menu-tile`: the `nbt-aa-tile` release folder. `idrive-plus-plugins`:
the `chiavetta` install folder. `entry-aad`: the extracted `entry-aad-<version>` folder (with its
`opt/aa` and `opt/hmi/data/ro/Plugins/EntryAad` trees); edit `/var/local/data/AA/vehicle` for the car.

## Not part of the SSH flow

- **iDrive Plus phone app** — an Android APK (sideloaded from its release). The toolbox installs
  the *HU plugins*; the phone app is separate. News/fuel/traffic data is Italy-only as shipped.
- **Remote-start FSC** — a different ECU (DME/BDC3, mainly G-series), applied with **E-Sys**, not
  the NBT Evo SSH. It's referenced only (`NOTICES.md`), experimental, and unlicensed — use the
  author's generator directly and install the resulting `.fsc` with E-Sys. It shares the
  low-exponent self-signed FSC approach used elsewhere, so it can inform the CarPlay FSC work
  (`docs/CARPLAY_ACTIVATE_FSC.md`).
